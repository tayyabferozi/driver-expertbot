module.exports = {
  errorFormatter: ({ msg }) => {
    return msg;
  },
};
